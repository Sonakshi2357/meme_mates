// models/User.js

const mongoose = require('mongoose');

// Define the user schema
const userSchema = new mongoose.Schema({
    username: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    moodBoard: { type: Array, default: [] },
    memesSent: { type: Array, default: [] },
    points: { type: Number, default: 0 },
    interests: { type: Array, default: [] },
    createdAt: { type: Date, default: Date.now }
});

// Create the User model
const User = mongoose.model('User ', userSchema);

module.exports = User;