document.addEventListener('DOMContentLoaded', () => {
    const ctaButton = document.querySelector('.cta-button');
    ctaButton.addEventListener('click', () => {
        alert('Thank you for your interest! Redirecting to the sign-up page...');
        // Here you can add logic to redirect to the sign-up page
        // window.location.href = 'signup.html'; // Uncomment and set the correct path
    });
});
``` ### 4. Additional Features (Optional)

To enhance the app further, consider implementing the following features:

#### 4.1. Mood Board Functionality

You can create a simple mood board feature using HTML5 Canvas or a library like Fabric.js to allow users to drag and drop images onto a canvas.

#### 4.2. Meme Messaging

Integrate a meme API (like Imgflip) to allow users to search for and send memes directly within the chat interface.

#### 4.3. Backend Integration

For a fully functional app, you would need a backend to handle user authentication, data storage, and real-time messaging. You can use Node.js with Express and a database like MongoDB.

### Example of a Simple Backend (Node.js)

```javascript
const express = require('express');
const mongoose = require('mongoose');
const app = express();
const PORT = process.env.PORT || 3000;

mongoose.connect('mongodb://localhost:27017/meetq', { useNewUrlParser: true, useUnifiedTopology: true });

app.use(express.json());

app.post('/api/users', (req, res) => {
    // Logic to create a new user
    res.status(201).send('User  created');
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});