// controllers/userController.js

const User = require('../models/User'); // Import the User model
const bcrypt = require('bcrypt');

// User registration logic
const registerUser  = async (req, res) => {
    const { username, password } = req.body;

    try {
        // Check if the user already exists
        const existingUser  = await User.findOne({ username });
        if (existingUser ) {
            return res.status(400).send('User  already exists');
        }

        // Hash the password
        const hashedPassword = await bcrypt.hash(password, 10);
        
        // Create a new user
        const newUser  = new User({ username, password: hashedPassword });
        await newUser .save();

        res.status(201).send('User  registered successfully');
    } catch (error) {
        res.status(500).send('Error registering user');
    }
};

// User login logic
const loginUser  = async (req, res) => {
    const { username, password } = req.body;

    try {
        // Find the user by username
        const user = await User.findOne({ username });
        if (!user) {
            return res.status(400).send('User  not found');
        }

        // Compare the password
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(400).send('Invalid password');
        }

        res.send('Login successful');
    } catch (error) {
        res.status(500).send('Error logging in user');
    }
};

// Export the controller functions
module.exports = {
    registerUser ,
    loginUser ,
};