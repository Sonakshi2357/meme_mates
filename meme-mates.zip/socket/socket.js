// socket/socket.js

const socketIo = require('socket.io');

const setupSocket = (server) => {
    const io = socketIo(server);

    io.on('connection', (socket) => {
        console.log('New user connected');

        socket.on('sendMessage', (message) => {
            io.emit('receiveMessage', message);
        });

        socket.on('disconnect', () => {
            console.log('User  disconnected');
        });
    });
};

module.exports = setupSocket;